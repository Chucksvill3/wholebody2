package com.example.wholebody

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
